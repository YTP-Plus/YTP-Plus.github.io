This hotfix applies a compiled lzma_native@v5.0.1 until ffmpeg_cli has been patched.
Place in your YTPPlusCLI folder.