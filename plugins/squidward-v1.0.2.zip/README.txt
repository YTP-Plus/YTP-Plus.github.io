squidward.js v1.0.2 by TeamPopplio
-------------------
This is the squidward plugin for ytp+ cli v0.3.4 or above.
Requires ImageMagick to be installed, install on Windows using "choco install imagemagick" or follow your platform's installation procedures.
Untested on Linux and macOS platforms.

Install:
Drag and drop plugins/ and shared/ into your ytp+ cli installation directory (likely YTPPlusCLI).
Install ImageMagick and make sure it is present in your system PATH variable, varies on your platform.
You're done! :)
--------------------------------------
https://ytp-plus.github.io/
https://discord.gg/8ppmspR6Wh
https://github.com/ytp-plus/