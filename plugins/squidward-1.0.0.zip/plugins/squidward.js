/* Requires ImageMagick to be installed - Version 1.0.0 */
const global = require("../global"),
	fs = require("fs"),
	child_process = require("child_process")
	os = require('os');;
module.exports = {
	plugin: (video, toolbox, cwd, debug) => {
		var input = video,
			output = cwd + "/shared/temp/"
			temp = output + "temp.mp4"; //og file
		
		// final result is backwards & forwards concatenated with music
		
		if (fs.existsSync(input))
			fs.renameSync(input,temp);

		var soundDir = cwd + "/shared";

		var randomSound = "squidward.wav";

		if(!randomSound) {
			if(debug) console.log("\nNo "+randomSound+" found in "+soundDir+"!")
			return false
		}

		global.ffmpeg.runSync("-i " + temp// -c:v copy"
				+ " -vf \"select=gte(n\\,1)\""
				+ " -vframes 1"
				+ " -y " + output + "squidward0.png"
				+ (debug == false ? " -hide_banner -loglevel quiet" : ""));
		
		let commands = [];

		for (var i=1; i<6; i++) { 
			let effect = "";
			var random = global.randomInt(0,6);
			switch (random) {
				case 0: 
					effect = " -flop";
					break;
				case 1:
					effect = " -flip";
					break;
				case 2:
					effect = " -implode -" +global.randomInt(1,3);
					break;
				case 3:
					effect = " -implode " +global.randomInt(1,3);
					break;
				case 4:
					effect = " -swirl " +global.randomInt(1,180);
					break;
				case 5:
					effect = " -swirl -" +global.randomInt(1,180);
					break;
				case 6:
					effect = " -channel RGB -negate";
					break;
				//case 7:
				//    effect = " -virtual-pixel Black +distort Cylinder2Plane " +global.randomInt(1,90);
				//    break;
			}
			commands.push("convert " + output + "squidward0.png"
					+ effect
					+ " " + output + "squidward" + i + ".png"
			);
		}
		commands.push("convert -size 640x480 canvas:black " + output + "black.png");
		
		if (fs.existsSync(output + "concatsquidward.txt"))
			fs.unlinkSync(output + "concatsquidward.txt");

		fs.writeFileSync(output + "concatsquidward.txt",
			"file 'squidward0.png'\n" +
			"duration 0.467\n" +
			"file 'squidward1.png'\n" +
			"duration 0.434\n" +
			"file 'squidward2.png'\n" +
			"duration 0.4\n" +
			"file 'black.png'\n" +
			"duration 0.834\n" +
			"file 'squidward3.png'\n" +
			"duration 0.467\n" +
			"file 'squidward4.png'\n" +
			"duration 0.4\n" +
			"file 'squidward5.png'\n" +
			"duration 0.467");

		for (var i = 0; i < commands.length; i++) {
			child_process.execSync((os.platform() == "win32" ? "magick " : "") + commands[i]);
		}

		global.ffmpeg.runSync("-f concat"
				+ " -i " + output + "concatsquidward.txt"
				+ " -i " + soundDir + "/" + randomSound
				+ " -map 0:v:0 -map 1:a:0"
				+ " -vf \"scale="+toolbox.width+"x"+toolbox.height+",setsar=1:1\""
				+ " -pix_fmt yuv420p"
				+ " -y " + video
				+ (debug == false ? " -hide_banner -loglevel quiet" : ""));
		
		fs.unlinkSync(temp);
		for (var i=0; i<6; i++) {
			fs.unlinkSync(output + "squidward"+i+".png");
		}
		fs.unlinkSync(output + "black.png");
		fs.unlinkSync(output + "concatsquidward.txt");
		return true
  	}
};
