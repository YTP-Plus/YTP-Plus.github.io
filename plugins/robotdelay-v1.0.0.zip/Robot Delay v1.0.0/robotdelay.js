/* robotdelay.js made by The British YTPer, idea from ClassicBirch - Version 1.0.0 */
const global = require("../global"),
	fs = require("fs");
module.exports = {
	plugin: (video, toolbox, cwd, debug) => {
		var temp = cwd + "/shared/temp/temp.mp4";
		if (fs.existsSync(temp))
			fs.unlinkSync(temp);
		if (fs.existsSync(video))
			fs.renameSync(video,temp);
		var command = "-i \"" + temp + "\" -c:v copy -af aecho=\"1:1:10|20|30|40|50|60|70|80|90|100|110|120|130|140|150|160|170|180|190|200:1|0.95|0.9|0.85|0.8|0.75|0.7|0.65|0.6|0.55|0.5|0.45|0.4|0.35|0.3|0.25|0.2|0.15|0.1|0.05\" -y \"" + video + "\"";
		global.ffmpeg.runSync(command + (debug == false ? " -hide_banner -loglevel quiet" : ""));
		fs.unlinkSync(temp);
		return true
  	}
};
