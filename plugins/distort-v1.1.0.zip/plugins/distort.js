/* By TeamPopplio - Requires ImageMagick to be installed - Version 1.1.0 */
const global = require("../global"),
	fs = require("fs"),
	child_process = require("child_process")
	os = require('os');;
module.exports = {
	plugin: (video, toolbox, cwd, debug) => {
		var input = video,
			output = cwd + "/shared/temp/",
			temp2 = output + "temp2.mp4";
			temp = output + "temp.mp4"; //og file
		
		// final result is backwards & forwards concatenated with music
		
		if (fs.existsSync(input))
			fs.renameSync(input,temp);

		var soundDir = cwd + "/shared/distort";

		if (!fs.existsSync(soundDir))
			fs.mkdirSync(soundDir) //init plugin

		var readDir = fs.readdirSync(soundDir),
			randomSound = readDir[global.randomInt(0,readDir.length-1)];
		if(!randomSound) {
			if(debug) console.log("\nNo sounds exist in directory '"+soundDir+"'!")
			return false
		}

		global.ffmpeg.runSync("-i \"" + temp + "\"" // -c:v copy"
				+ " -vf \"select=gte(n\\,1)\""
				+ " -vframes 1"
				+ " -y \"" + output + "distort0.png\""
				+ (debug == false ? " -hide_banner -loglevel quiet" : ""));
		
		let commands = [];

		for (var i=1; i<6; i++) { 
			let effect = "";
			var random = global.randomInt(0,6);
			switch (random) {
				case 0: 
					effect = " -flop";
					break;
				case 1:
					effect = " -flip";
					break;
				case 2:
					effect = " -implode -" +global.randomInt(1,3);
					break;
				case 3:
					effect = " -implode " +global.randomInt(1,3);
					break;
				case 4:
					effect = " -swirl " +global.randomInt(1,180);
					break;
				case 5:
					effect = " -swirl -" +global.randomInt(1,180);
					break;
				case 6:
					effect = " -channel RGB -negate";
					break;
				//case 7:
				//    effect = " -virtual-pixel Black +distort Cylinder2Plane " +global.randomInt(1,90);
				//    break;
			}
			commands.push("convert \"" + output + "distort0.png\""
					+ effect
					+ " \"" + output + "distort" + i + ".png\""
			);
		}
		commands.push("convert -size "+toolbox.width+"x"+toolbox.height+" canvas:black \"" + output + "black.png\"");
		
		if (fs.existsSync(output + "concatdistort.txt"))
			fs.unlinkSync(output + "concatdistort.txt");

		fs.writeFileSync(output + "concatdistort.txt",
			"file 'distort0.png'\n" +
			"duration 0.467\n" +
			"file 'distort1.png'\n" +
			"duration 0.434\n" +
			"file 'distort2.png'\n" +
			"duration 0.4\n" +
			"file 'black.png'\n" +
			"duration 0.834\n" +
			"file 'distort3.png'\n" +
			"duration 0.467\n" +
			"file 'distort4.png'\n" +
			"duration 0.4\n" +
			"file 'distort5.png'\n" +
			"duration 0.467");

		for (var i = 0; i < commands.length; i++) {
			child_process.execSync((os.platform() == "win32" ? "magick " : "") + commands[i]);
		}

		global.ffmpeg.runSync("-f concat -safe 0"
			+ " -i \"" + output + "concatdistort.txt\""
			+ " -i \"" + soundDir + "/" + randomSound + "\""
			+ " -map 0:v:0 -map 1:a:0"
			+ " -vf \"scale="+toolbox.width+"x"+toolbox.height+",setsar=1:1\""
			+ " -af aresample=async=1 -y \"" + temp2 + "\""
			+ (debug == false ? " -hide_banner -loglevel quiet" : ""));
		
		global.ffmpeg.runSync(" -i \"" + temp2 + "\""
			+ " -pix_fmt yuv420p -vf scale="+toolbox.width+"x"+toolbox.height+",setsar=1:1,fps=fps="+toolbox.fps + " -ar 44100 -ac 2 -map_metadata -1 -map_chapters -1 -y \"" + video + "\""
			+ (debug == false ? " -hide_banner -loglevel quiet" : ""));

		fs.unlinkSync(temp2);	
		fs.unlinkSync(temp);
		for (var i=0; i<6; i++) {
			fs.unlinkSync(output + "distort"+i+".png");
		}
		fs.unlinkSync(output + "black.png");
		fs.unlinkSync(output + "concatdistort.txt");
		return true
  	}
};
